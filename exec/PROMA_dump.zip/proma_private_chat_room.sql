-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6c107.p.ssafy.io    Database: proma
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `private_chat_room`
--

DROP TABLE IF EXISTS `private_chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_chat_room` (
  `private_chat_room_no` int NOT NULL AUTO_INCREMENT,
  `publisher_no` varchar(15) DEFAULT NULL,
  `subscriber_no` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`private_chat_room_no`),
  KEY `FK448el0qfpr7qw1naaw9ff84rt` (`publisher_no`),
  KEY `FKakhsflku0lvrduajvpi40tvsy` (`subscriber_no`),
  CONSTRAINT `FK448el0qfpr7qw1naaw9ff84rt` FOREIGN KEY (`publisher_no`) REFERENCES `user` (`user_no`),
  CONSTRAINT `FKakhsflku0lvrduajvpi40tvsy` FOREIGN KEY (`subscriber_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_chat_room`
--

LOCK TABLES `private_chat_room` WRITE;
/*!40000 ALTER TABLE `private_chat_room` DISABLE KEYS */;
INSERT INTO `private_chat_room` VALUES (42,'YbfpeziJGN68eeE','YbfpeziJGN68eeE'),(43,'pyjLhp2lPBBEvlt','YbfpeziJGN68eeE'),(44,'YbfpeziJGN68eeE','TXBFO9ZQjlrzrNr'),(45,'TXBFO9ZQjlrzrNr','TXBFO9ZQjlrzrNr'),(46,'YbfpeziJGN68eeE','WWvYLZcOtIpv7K0'),(47,'WWvYLZcOtIpv7K0','TXBFO9ZQjlrzrNr'),(48,'pyjLhp2lPBBEvlt','TXBFO9ZQjlrzrNr'),(49,'WWvYLZcOtIpv7K0','WWvYLZcOtIpv7K0'),(50,'pyjLhp2lPBBEvlt','WWvYLZcOtIpv7K0'),(51,'pyjLhp2lPBBEvlt','pyjLhp2lPBBEvlt'),(52,'pyjLhp2lPBBEvlt','llx3USSspeUsBFN'),(53,'llx3USSspeUsBFN','TXBFO9ZQjlrzrNr'),(54,'llx3USSspeUsBFN','WWvYLZcOtIpv7K0'),(55,'llx3USSspeUsBFN','YbfpeziJGN68eeE'),(56,'llx3USSspeUsBFN','llx3USSspeUsBFN'),(57,'l5jzzjksjMQuM8g','WWvYLZcOtIpv7K0'),(58,'l5jzzjksjMQuM8g','TXBFO9ZQjlrzrNr'),(59,'l5jzzjksjMQuM8g','YbfpeziJGN68eeE'),(60,'llx3USSspeUsBFN','l5jzzjksjMQuM8g'),(61,'pyjLhp2lPBBEvlt','l5jzzjksjMQuM8g'),(62,'l5jzzjksjMQuM8g','l5jzzjksjMQuM8g');
/*!40000 ALTER TABLE `private_chat_room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 17:26:06
