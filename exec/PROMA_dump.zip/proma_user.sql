-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6c107.p.ssafy.io    Database: proma
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_no` varchar(15) NOT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `nickname` varchar(15) DEFAULT NULL,
  `profile_image` varchar(300) DEFAULT NULL,
  `node_id` varchar(30) DEFAULT NULL,
  `refresh` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1cX1fkXupaZsMEp',_binary '','Daboni','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/proma.png','MDQ6VXNlcjYwMzkzOTc3','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTgxMjd9.KdZWcaINIKCwT-oFnmfZAWvkEdCPrl2-91GfP1GU6rNvipl8ZrM7IM-ijZ-RjBYjdLl_JXI6Qhh1oxmRT-D1ig'),('l5jzzjksjMQuM8g',_binary '\0','som','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/5c7ebaa8-93a8-4edb-99de-f762595f5e14l5jzzjksjMQuM8g','MDQ6VXNlcjg5NjQwNzA1','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTgzOTR9.Ib1dXoTf4aZfSnxXH7tQKtpOyRYOIGYGWK1IyKEzBsmXy0_nD4dQGnlyBWec5ZD5cWKgu-nJJ134cec2J0vgfw'),('llx3USSspeUsBFN',_binary '\0','Daboni','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/f8bc013b-6185-480c-8564-5a154dd2d89dllx3USSspeUsBFN','MDQ6VXNlcjYwMzkzOTc3','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTgyMDl9.Q-2vNt8mEU53bbVA1uv-xHMb5v6xXHablCFryF4fhC6SgraBpHQ_wNsT43PHzx6QoV50ykCr3Tko2dPPOzXcyA'),('pyjLhp2lPBBEvlt',_binary '\0','서은민','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/6c93ee15-2aec-4963-8cdb-2df32030aed8pyjLhp2lPBBEvlt','MDQ6VXNlcjUwNjU4MTUz','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTc5MDh9.bqQjjWD18pvx9zBL72go9YQkfZJEdC57-SkWa1ZGkbFxQBsa-g3m1sCCGnzPyJnCpu3VV6djQFxSyEu1RwAhng'),('SVMqW2ppOWqLDjj',_binary '','cjscoding','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/proma.png','MDQ6VXNlcjc3OTE1NjE2','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTc4NjZ9.dVFHO_SPz5uK34mZ3Bp5lsjAIlAk7Cz0073b1BRA0Gqfczw8X8pSI4RelRG9a-5V0QrN6KRoCWyc_hZk_k5nIw'),('TXBFO9ZQjlrzrNr',_binary '\0','parkjoohan','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/proma.png','MDQ6VXNlcjg1MDA2NTM2','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTgyMTl9.iQNdjiZkI6PQz-BrHrGupa2w-LflCSuw32xy29GckTsBp50_4qTbUedntAxc-wRzJ46PFIKRCMLwUyHdIndYTg'),('WWvYLZcOtIpv7K0',_binary '\0','ilhwan','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/80aec83c-be0d-48b9-aa10-f9bc32d5beacWWvYLZcOtIpv7K0','MDQ6VXNlcjQzMDU3NjQ4','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NTg4NDl9.rQOlX3YzQADoXsvc0ipBdp61b5AsNZ9b6UiQ_ZpP-kPbTkRS1qVMFxrQenE3z-F9G72-O2juziPZhbwVgQYdzQ'),('YbfpeziJGN68eeE',_binary '\0','Sue','https://promaproject.s3.ap-northeast-2.amazonaws.com/image/f35457ce-f2e2-47b2-8468-3e94b95a2677YbfpeziJGN68eeE','MDQ6VXNlcjc3OTE1NjE2','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqd3TthqDtgbAiLCJleHAiOjE2NTI4NjEyMzJ9.eUI8l7bOTMbhnd0ysQon99_pJH2N51PVy4S18GbRWJ5s9yL-KGqHlem1i3wG2jdVOXh9P-yglxai-rro97eQbg');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 17:26:09
