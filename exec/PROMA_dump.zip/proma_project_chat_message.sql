-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6c107.p.ssafy.io    Database: proma
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_chat_message`
--

DROP TABLE IF EXISTS `project_chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_chat_message` (
  `project_chat_message_no` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `time` datetime(6) DEFAULT NULL,
  `project_room_no` int DEFAULT NULL,
  `user_no` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`project_chat_message_no`),
  KEY `FK3l9o8mb4e52m1qrp8rn4ejg96` (`project_room_no`),
  KEY `FKl6nrdetetkroh05s3c68gg1hf` (`user_no`),
  CONSTRAINT `FK3l9o8mb4e52m1qrp8rn4ejg96` FOREIGN KEY (`project_room_no`) REFERENCES `project_chat_room` (`project_chat_room_no`),
  CONSTRAINT `FKl6nrdetetkroh05s3c68gg1hf` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_chat_message`
--

LOCK TABLES `project_chat_message` WRITE;
/*!40000 ALTER TABLE `project_chat_message` DISABLE KEYS */;
INSERT INTO `project_chat_message` VALUES (277,'여러분 안녕하세요','2022-05-17 16:21:14.528037',33,'l5jzzjksjMQuM8g'),(278,'안뇽하세요~','2022-05-17 16:34:19.718287',33,'YbfpeziJGN68eeE'),(279,'안녕하세요!','2022-05-17 16:35:38.393283',33,'pyjLhp2lPBBEvlt'),(281,'안녕하세요','2022-05-17 17:17:34.652221',33,'llx3USSspeUsBFN'),(282,'안녕안녕 안녕하세요~','2022-05-17 17:17:41.112928',33,'WWvYLZcOtIpv7K0'),(283,'안되나요??','2022-05-17 17:17:41.140812',33,'TXBFO9ZQjlrzrNr'),(284,'잘 되네여!!!!','2022-05-17 17:17:45.069684',33,'TXBFO9ZQjlrzrNr'),(285,'저 오늘 할 거 완료했습니다','2022-05-17 17:17:52.322458',33,'llx3USSspeUsBFN'),(286,'주한님 이미지 통신 부분 다시 확인할 사항 있습니다.','2022-05-17 17:18:08.558885',33,'WWvYLZcOtIpv7K0'),(287,'프론트는 오늘 계획대로 잘 끝낼거 같습니다','2022-05-17 17:18:16.668905',33,'TXBFO9ZQjlrzrNr'),(288,'팀 채팅 인원 -1 없애주세요!','2022-05-17 17:18:27.137064',33,'pyjLhp2lPBBEvlt'),(289,'-------------------------------------------------------------------','2022-05-17 17:20:31.036338',33,'YbfpeziJGN68eeE'),(290,'뿐만 아니라 오늘 안에 발생한 에러들 3개는 다 처리하고 넘어가야 할 것 같습니다.','2022-05-17 17:20:32.489826',33,'WWvYLZcOtIpv7K0'),(291,'-------------------------------------------------------------------','2022-05-17 17:20:42.224552',33,'YbfpeziJGN68eeE'),(292,'-------------------------------------------','2022-05-17 17:20:47.260314',33,'YbfpeziJGN68eeE'),(293,'프론트 마스터로 머지 했습니다!','2022-05-17 17:21:12.983850',33,'YbfpeziJGN68eeE'),(294,'주한님 이미지 통신 부분 확인 사항 있습니다.','2022-05-17 17:21:15.785929',33,'WWvYLZcOtIpv7K0'),(295,'확인부탁합니다.','2022-05-17 17:21:24.543283',33,'YbfpeziJGN68eeE'),(296,'수정 사항 있으면 바로 알려주세요.','2022-05-17 17:21:39.201079',33,'llx3USSspeUsBFN'),(297,'머지 확인했습니다!','2022-05-17 17:21:54.133613',33,'pyjLhp2lPBBEvlt'),(298,'머지 확인했습니다!2','2022-05-17 17:22:02.917426',33,'llx3USSspeUsBFN'),(299,'이미지 용량이 초과시 에러 수정해주세요.','2022-05-17 17:22:08.794096',33,'WWvYLZcOtIpv7K0'),(300,'5MB 이하 처리했습니다!','2022-05-17 17:22:33.517978',33,'YbfpeziJGN68eeE'),(301,'넵 확인했습니다.','2022-05-17 17:22:46.764196',33,'WWvYLZcOtIpv7K0'),(302,'확인이용','2022-05-17 17:22:52.546730',33,'l5jzzjksjMQuM8g'),(303,'이전 대화목록 불러오기 해결해주세요ㅎㅎ','2022-05-17 17:22:53.366209',33,'pyjLhp2lPBBEvlt'),(304,'이미지 확인 사항이 뭔가요?','2022-05-17 17:23:03.387658',33,'TXBFO9ZQjlrzrNr');
/*!40000 ALTER TABLE `project_chat_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 17:26:04
