-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6c107.p.ssafy.io    Database: proma
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `notification_no` int NOT NULL AUTO_INCREMENT,
  `checked` tinyint(1) DEFAULT '0',
  `message` varchar(100) DEFAULT NULL,
  `notification_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_no` varchar(15) NOT NULL,
  PRIMARY KEY (`notification_no`),
  KEY `FKm52040ahduq809a30dsgd9t7d` (`user_no`),
  CONSTRAINT `FKm52040ahduq809a30dsgd9t7d` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=474 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (438,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','YbfpeziJGN68eeE'),(439,1,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','pyjLhp2lPBBEvlt'),(440,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','TXBFO9ZQjlrzrNr'),(441,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','WWvYLZcOtIpv7K0'),(442,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','llx3USSspeUsBFN'),(443,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:24:07','l5jzzjksjMQuM8g'),(444,0,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','YbfpeziJGN68eeE'),(445,1,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','pyjLhp2lPBBEvlt'),(446,0,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','TXBFO9ZQjlrzrNr'),(447,0,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','WWvYLZcOtIpv7K0'),(448,0,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','llx3USSspeUsBFN'),(449,0,'PROMA PJT\n스프린트 1st week 가 종료되었습니다.','2022-05-17 16:24:13','l5jzzjksjMQuM8g'),(450,0,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','YbfpeziJGN68eeE'),(451,1,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','pyjLhp2lPBBEvlt'),(452,0,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','TXBFO9ZQjlrzrNr'),(453,0,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','WWvYLZcOtIpv7K0'),(454,0,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','llx3USSspeUsBFN'),(455,0,'PROMA PJT\n스프린트 2nd week 가 시작되었습니다.','2022-05-17 16:24:30','l5jzzjksjMQuM8g'),(456,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','YbfpeziJGN68eeE'),(457,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','pyjLhp2lPBBEvlt'),(458,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','TXBFO9ZQjlrzrNr'),(459,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','WWvYLZcOtIpv7K0'),(460,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','llx3USSspeUsBFN'),(461,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 16:26:12','l5jzzjksjMQuM8g'),(462,0,'PROMA PJT\n토픽 Setting 의 이슈 backend setting 이/가 완료되었습니다.','2022-05-17 16:32:13','TXBFO9ZQjlrzrNr'),(463,0,'PROMA PJT\n토픽 Setting 의 이슈 backend setting 이/가 완료되었습니다.','2022-05-17 16:32:13','llx3USSspeUsBFN'),(464,0,'PROMA PJT\n토픽 Setting 의 이슈 backend setting 이/가 완료되었습니다.','2022-05-17 16:32:13','YbfpeziJGN68eeE'),(465,0,'PROMA PJT\n토픽 Setting 의 이슈 initial setting 이/가 완료되었습니다.','2022-05-17 16:49:52','YbfpeziJGN68eeE'),(466,0,'PROMA PJT\n토픽 Setting 의 이슈 initial setting 이/가 완료되었습니다.','2022-05-17 16:49:52','TXBFO9ZQjlrzrNr'),(467,0,'PROMA PJT\n토픽 Setting 의 이슈 initial setting 이/가 완료되었습니다.','2022-05-17 16:49:52','llx3USSspeUsBFN'),(468,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','YbfpeziJGN68eeE'),(469,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','pyjLhp2lPBBEvlt'),(470,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','TXBFO9ZQjlrzrNr'),(471,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','WWvYLZcOtIpv7K0'),(472,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','llx3USSspeUsBFN'),(473,0,'PROMA PJT\n스프린트 1st week 가 시작되었습니다.','2022-05-17 17:16:35','l5jzzjksjMQuM8g');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 17:26:08
