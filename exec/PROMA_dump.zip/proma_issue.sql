-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6c107.p.ssafy.io    Database: proma
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issue`
--

DROP TABLE IF EXISTS `issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue` (
  `issue_no` int NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `sprint_no` int DEFAULT NULL,
  `team_no` int NOT NULL,
  `topic_no` int NOT NULL,
  `assignee` varchar(15) NOT NULL,
  PRIMARY KEY (`issue_no`),
  KEY `FKrv9xakw4pd9jwyy9rno7qbj6q` (`sprint_no`),
  KEY `FKqc0vrqxc7q1o4n8v29dr33ft3` (`team_no`),
  KEY `FK1qdopqw4fixcrd147sefpw4ow` (`topic_no`),
  KEY `FKg2bf5yjdah0466tfhspvg4wxd` (`assignee`),
  CONSTRAINT `FK1qdopqw4fixcrd147sefpw4ow` FOREIGN KEY (`topic_no`) REFERENCES `topic` (`topic_no`),
  CONSTRAINT `FKg2bf5yjdah0466tfhspvg4wxd` FOREIGN KEY (`assignee`) REFERENCES `user` (`user_no`),
  CONSTRAINT `FKqc0vrqxc7q1o4n8v29dr33ft3` FOREIGN KEY (`team_no`) REFERENCES `team` (`team_no`),
  CONSTRAINT `FKrv9xakw4pd9jwyy9rno7qbj6q` FOREIGN KEY (`sprint_no`) REFERENCES `sprint` (`sprint_no`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue`
--

LOCK TABLES `issue` WRITE;
/*!40000 ALTER TABLE `issue` DISABLE KEYS */;
INSERT INTO `issue` VALUES (138,'backend setting','todo','backend setting',68,65,35,'llx3USSspeUsBFN'),(139,'wire frame','todo','wire frame',69,64,35,'YbfpeziJGN68eeE'),(140,'제작할 프론트엔드 와이어프레임 제작','todo','와이어프레임 제작',68,64,35,'TXBFO9ZQjlrzrNr'),(141,'initial setting','done','initial setting',68,64,35,'YbfpeziJGN68eeE'),(142,'데이터베이스 설계하기','inprogress','DB 설계',68,65,37,'pyjLhp2lPBBEvlt'),(143,'채팅 API 개발','todo','채팅 API 개발',68,65,38,'l5jzzjksjMQuM8g'),(144,'study OAuth','todo','study OAuth',68,65,36,'WWvYLZcOtIpv7K0');
/*!40000 ALTER TABLE `issue` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 17:26:06
